import "./BlueButton.css"

export default function BlueButton({ text, onC = ()=>{} }) {
    return (
        <button className="blueButton" onClick={onC}>{text}</button>
    )
}