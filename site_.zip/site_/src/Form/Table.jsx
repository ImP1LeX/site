import { useEffect, useState } from "react"

export default function Table({
    title,
    data,
    editing
}) {
    const [disabled, setDisabled] = useState(true)
    return (
        <div className="elemBlock">
            
                <h2 className="titleForm">{title}</h2>
                <div className="preTableBlock">
                    <div className="tableBlock">
                            <div className='tableLine'>
                                {
                                data[0][0].map((elem)=>{
                                    return<><div className='tableLineElem'>{elem}</div></>
                                })
                                
                                }
                            </div>
                            <div className='bottomLine' style={{width:`${data[0][0].length * 500}px`}}></div>
                            <div className='tableLine' style={{padding: '0 0 30px 0'}}>
                                {
                                    data[0][1].map((elem)=>{
                                        return<><div className='tableLineElem'><input value={elem} disabled={disabled}></input></div></>
                                    })
                                }
                            </div>
                    </div>
                    <div className='buttonBlock'>
                        {
                            editing ?
                            <>
                            <button onClick={()=>{
                                setDisabled(false)
                            }}><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none">
                            <g clip-path="url(#clip0_237_406)">
                                <path d="M8 12.6667L12.6667 8L14.6667 10L10 14.6667L8 12.6667Z" stroke="#009EF7" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"/>
                                <path d="M11.9999 8.66671L10.9999 3.66671L1.33325 1.33337L3.66659 11L8.66658 12L11.9999 8.66671Z" stroke="#009EF7" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"/>
                                <path d="M1.33325 1.33337L6.39059 6.39071" stroke="#009EF7" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"/>
                                <path d="M7.33333 8.66667C8.06971 8.66667 8.66667 8.06971 8.66667 7.33333C8.66667 6.59695 8.06971 6 7.33333 6C6.59695 6 6 6.59695 6 7.33333C6 8.06971 6.59695 8.66667 7.33333 8.66667Z" stroke="#009EF7" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"/>
                            </g>
                            <defs>
                                <clipPath id="clip0_237_406">
                                <rect width="16" height="16" fill="white"/>
                                </clipPath>
                            </defs>
                            </svg></button>
                            <button onClick={()=>{
                                setDisabled(true)
                            }}><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none">
                            <path d="M12.6667 14H3.33333C2.97971 14 2.64057 13.8595 2.39052 13.6095C2.14048 13.3594 2 13.0203 2 12.6667V3.33333C2 2.97971 2.14048 2.64057 2.39052 2.39052C2.64057 2.14048 2.97971 2 3.33333 2H10.6667L14 5.33333V12.6667C14 13.0203 13.8595 13.3594 13.6095 13.6095C13.3594 13.8595 13.0203 14 12.6667 14Z" stroke="#656565" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"/>
                            <path d="M11.3333 14V8.66663H4.66663V14" stroke="#656565" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"/>
                            <path d="M4.66663 2V5.33333H9.99996" stroke="#656565" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg></button>
                            </>
                            :
                            <>
                                <button>
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none">
                                        <path d="M8.66675 1.33331H4.00008C3.64646 1.33331 3.30732 1.47379 3.05727 1.72384C2.80722 1.97389 2.66675 2.31302 2.66675 2.66665V13.3333C2.66675 13.6869 2.80722 14.0261 3.05727 14.2761C3.30732 14.5262 3.64646 14.6666 4.00008 14.6666H12.0001C12.3537 14.6666 12.6928 14.5262 12.9429 14.2761C13.1929 14.0261 13.3334 13.6869 13.3334 13.3333V5.99998L8.66675 1.33331Z" stroke="#656565" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"/>
                                        <path d="M8.66675 1.33331V5.99998H13.3334" stroke="#656565" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                                </button>
                            </>
                        }
                    </div>
                </div>
        </div>
    )
}

