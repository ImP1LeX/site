import React from 'react'
import ReactDOM from 'react-dom/client'
import Entry from './Entry/Entry'
import Form from './Form/Form';
import {
    createBrowserRouter,
    RouterProvider,
  } from "react-router-dom";
import './index.css'
import AdminForm from './AdminForm/AdminForm';
import Admin from './Admin/Admin';

const router = createBrowserRouter([
    {
      path: "/",
      element: <Form />,
    },
    {
      path: "/admin",
      element: <Admin />,
    },
    {
      path: "/auth",
      element: <Entry />,
    },
      {
        path: "/admin/curent",
        element: <AdminForm />,
      },
  ]);

ReactDOM.createRoot(document.getElementById('root')).render(
    <RouterProvider router={router} />
    
)
